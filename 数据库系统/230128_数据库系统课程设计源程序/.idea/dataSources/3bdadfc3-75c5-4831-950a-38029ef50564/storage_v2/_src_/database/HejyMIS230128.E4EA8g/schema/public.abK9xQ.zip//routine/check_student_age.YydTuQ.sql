create function check_student_age() returns trigger
    language plpgsql
as
$$
DECLARE
    student_age INTEGER;
BEGIN
    student_age := CAST(NEW.hjy_Sage230128 AS INTEGER);

    IF student_age <= 0 OR student_age > 100 OR student_age <> NEW.hjy_Sage230128 THEN
        RAISE EXCEPTION '年龄输入不正确: %', NEW.hjy_Sage230128;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function check_student_age() owner to opengaussuser;

