create function hejy_select_courses_score_to_upload230128(cname character varying, clname character varying, year character varying)
    returns TABLE(hjy_cno230128 character varying, hjy_cname230128 character varying, hjy_scscore230128 integer, hjy_sno230128 character varying, hjy_sname230128 character varying, hjy_clno230128 character varying, hjy_clname230128 character varying, hjy_scyear230128 character varying)
    language plpgsql
as
$$
DECLARE
    ss RECORD;
BEGIN
    FOR ss IN
        SELECT
            Courses.hjy_Cno230128,
            Courses.hjy_Cname230128,
            sc.hjy_SCscore230128,
            sc.hjy_Sno230128,
            students.hjy_Sname230128,
            Classes.hjy_clno230128,
            Classes.hjy_clname230128,
            sc.hjy_SCyear230128
        FROM
            hejy_Sc230128 AS sc
        JOIN
            hejy_Courses230128 AS Courses ON sc.hjy_Cno230128 = Courses.hjy_Cno230128
        JOIN
            hejy_classes230128 AS Classes ON sc.hjy_clno230128 = Classes.hjy_clno230128
        JOIN
            hejy_Students230128 AS students ON sc.hjy_Sno230128 = students.hjy_Sno230128
        WHERE
            Courses.hjy_Cname230128 = Cname
            AND Classes.hjy_clname230128 = Clname
            AND sc.hjy_SCyear230128 = year
    LOOP
        hjy_Cno230128 := ss.hjy_Cno230128;
        hjy_Cname230128 := ss.hjy_Cname230128;
        hjy_SCscore230128 := ss.hjy_SCscore230128;
        hjy_Sno230128 := ss.hjy_Sno230128;
        hjy_Sname230128 := ss.hjy_Sname230128;
        hjy_clno230128 := ss.hjy_clno230128;
        hjy_clname230128 := ss.hjy_clname230128;
        hjy_SCyear230128 := ss.hjy_SCyear230128;
        
        RETURN NEXT;
    END LOOP;
    
    RETURN;
END;
$$;

alter function hejy_select_courses_score_to_upload230128(varchar, varchar, varchar) owner to opengaussuser;

