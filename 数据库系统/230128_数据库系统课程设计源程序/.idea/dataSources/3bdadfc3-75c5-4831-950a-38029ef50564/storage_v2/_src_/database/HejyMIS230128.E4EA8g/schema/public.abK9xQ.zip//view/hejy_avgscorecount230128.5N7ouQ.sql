create view hejy_avgscorecount230128(hjy_cname230128, hjy_scyear230128, avgscore) as
SELECT hejy_courses230128.hjy_cname230128,
       hejy_sc230128.hjy_scyear230128,
       avg(hejy_sc230128.hjy_scscore230128) AS avgscore
FROM hejy_courses230128
         JOIN hejy_sc230128 ON hejy_courses230128.hjy_cno230128::text = hejy_sc230128.hjy_cno230128::text
GROUP BY hejy_courses230128.hjy_cname230128, hejy_sc230128.hjy_scyear230128;

alter table hejy_avgscorecount230128
    owner to opengaussuser;

