create function update_student_gpa() returns trigger
    language plpgsql
as
$$
DECLARE
    total_credits DOUBLE PRECISION;
    total_grade_points DOUBLE PRECISION;
    student_GPA DOUBLE PRECISION;
BEGIN
    -- 计算总学分和总绩点
    SELECT
        SUM(c.hjy_Ccredit230128),
        SUM(c.hjy_Ccredit230128 * (CASE WHEN sc.hjy_SCscore230128 >= 60 THEN ((sc.hjy_SCscore230128 - 50) / 10) ELSE 0 END))
    INTO
        total_credits,
        total_grade_points
    FROM
        hejy_Sc230128 sc
        JOIN hejy_Courses230128 c ON sc.hjy_Cno230128 = c.hjy_Cno230128
    WHERE
        sc.hjy_Sno230128 = NEW.hjy_Sno230128;

    -- 计算学生绩点
    IF total_credits > 0 THEN
        student_GPA := total_grade_points / total_credits;
    ELSE
        student_GPA := 0;
    END IF;

    -- 更新学生绩点和总学分
    UPDATE hejy_Students230128
    SET hjy_Sscore230128 = student_GPA,
        hjy_Scredits230128 = total_credits
    WHERE hjy_Sno230128 = NEW.hjy_Sno230128;

    RETURN NEW;
END;
$$;

alter function update_student_gpa() owner to opengaussuser;

