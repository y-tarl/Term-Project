create function hejy_select_place_by_classes230128(clname character varying)
    returns TABLE(hjy_sno230128 character varying, hjy_sname230128 character varying, hjy_ssex230128 character varying, hjy_sscore230128 double precision, hjy_clno230128 character varying, hjy_clname230128 character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        sc.hjy_Sno230128,
        students.hjy_Sname230128,
        students.hjy_Ssex230128,
        students.hjy_Sscore230128,
        sc.hjy_clno230128,
        Classes.hjy_clname230128
    FROM
        hejy_Sc230128 AS sc
    JOIN
        hejy_Students230128 AS students ON sc.hjy_Sno230128 = students.hjy_Sno230128
    JOIN
        hejy_classes230128 AS Classes ON sc.hjy_clno230128 = Classes.hjy_clno230128
    WHERE
        Classes.hjy_clname230128 = Clname
    ORDER BY
        students.hjy_Sscore230128 DESC;

    RETURN;
END;
$$;

alter function hejy_select_place_by_classes230128(varchar) owner to opengaussuser;

