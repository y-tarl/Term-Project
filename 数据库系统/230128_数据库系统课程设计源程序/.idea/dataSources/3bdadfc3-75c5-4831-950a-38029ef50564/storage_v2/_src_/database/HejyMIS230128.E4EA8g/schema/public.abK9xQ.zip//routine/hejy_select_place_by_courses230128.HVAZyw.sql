create function hejy_select_place_by_courses230128(cname character varying, year character varying)
    returns TABLE(hjy_cno230128 character varying, hjy_cname230128 character varying, hjy_scscore230128 integer, hjy_sno230128 character varying, hjy_sname230128 character varying, hjy_clno230128 character varying, hjy_clname230128 character varying, hjy_scyear230128 character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        Courses.hjy_Cno230128,
        Courses.hjy_Cname230128,
        sc.hjy_SCscore230128,
        sc.hjy_Sno230128,
        students.hjy_Sname230128,
        Classes.hjy_clno230128,
        Classes.hjy_clname230128,
        sc.hjy_SCyear230128
    FROM
        hejy_Sc230128 AS sc
    JOIN
        hejy_Courses230128 AS Courses ON sc.hjy_Cno230128 = Courses.hjy_Cno230128
    JOIN
        hejy_Students230128 AS students ON sc.hjy_Sno230128 = students.hjy_Sno230128
    JOIN
        hejy_classes230128 AS Classes ON sc.hjy_clno230128 = Classes.hjy_clno230128
    WHERE
        Courses.hjy_Cname230128 = Cname
        AND sc.hjy_SCyear230128 = year
    ORDER BY
        sc.hjy_SCscore230128 DESC;

    RETURN;
END;
$$;

alter function hejy_select_place_by_courses230128(varchar, varchar) owner to opengaussuser;

