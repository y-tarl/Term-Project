create function hejy_select_place_by_majors230128(mname character varying)
    returns TABLE(hjy_sno230128 character varying, hjy_sname230128 character varying, hjy_ssex230128 character varying, hjy_sscore230128 double precision, hjy_clno230128 character varying, hjy_clname230128 character varying, hjy_mno230128 character varying, hjy_mname230128 character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        students.hjy_Sno230128,
        students.hjy_Sname230128,
        students.hjy_Ssex230128,
        students.hjy_Sscore230128,
        Classes.hjy_clno230128,
        Classes.hjy_clname230128,
        majors.hjy_mno230128,
        majors.hjy_Mname230128
    FROM
        hejy_Students230128 AS students
    JOIN
        hejy_classes230128 AS Classes ON students.hjy_clno230128 = Classes.hjy_clno230128
    JOIN
        hejy_Majors230128 AS majors ON Classes.hjy_mno230128 = majors.hjy_mno230128
    WHERE
        majors.hjy_Mname230128 = Mname
    ORDER BY
        students.hjy_Sscore230128 DESC;

    RETURN;
END;
$$;

alter function hejy_select_place_by_majors230128(varchar) owner to opengaussuser;

