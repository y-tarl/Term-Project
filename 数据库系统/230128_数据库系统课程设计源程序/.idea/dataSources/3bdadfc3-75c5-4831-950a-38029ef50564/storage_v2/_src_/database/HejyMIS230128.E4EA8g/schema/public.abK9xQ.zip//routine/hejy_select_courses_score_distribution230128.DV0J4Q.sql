create function hejy_select_courses_score_distribution230128(cname character varying, year character varying)
    returns TABLE(num character varying)
    language plpgsql
as
$$
DECLARE
    sd RECORD;
BEGIN
    FOR sd IN
        SELECT
            COUNT(*) AS num
        FROM
            hejy_Sc230128 AS sc
        JOIN
            hejy_Courses230128 AS Courses ON sc.hjy_Cno230128 = Courses.hjy_Cno230128
        WHERE
            Courses.hjy_Cname230128 = Cname
            AND sc.hjy_SCyear230128 = year
        GROUP BY
            sc.hjy_SCscore230128
    LOOP
        num := sd.num;
        
        RETURN NEXT;
    END LOOP;
    
    RETURN;
END;
$$;

alter function hejy_select_courses_score_distribution230128(varchar, varchar) owner to opengaussuser;

