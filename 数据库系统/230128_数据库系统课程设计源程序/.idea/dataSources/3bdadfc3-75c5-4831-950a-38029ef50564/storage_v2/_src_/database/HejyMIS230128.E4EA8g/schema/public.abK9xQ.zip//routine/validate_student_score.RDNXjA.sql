create function validate_student_score() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.hjy_SCscore230128 < 0 OR NEW.hjy_SCscore230128 > 100 THEN
        RAISE EXCEPTION '成绩输入有误！成绩必须在0-100之间！';
    END IF;
    
    RETURN NEW;
END;
$$;

alter function validate_student_score() owner to opengaussuser;

