create function hejy_select_teachers_courses230128(tname character varying)
    returns TABLE(hjy_tno230128 character varying, hjy_tname230128 character varying, hjy_cno230128 character varying, hjy_clname230128 character varying, hjy_tcyear230128 character varying, hjy_cname230128 character varying)
    language plpgsql
as
$$
DECLARE
    tc RECORD;
BEGIN
    FOR tc IN
        SELECT DISTINCT
            teachers.hjy_Tno230128,
            teachers.hjy_Tname230128,
            Courses.hjy_Cno230128,
            Classes.hjy_clname230128,
            tc.hjy_TCyear230128,
            Courses.hjy_Cname230128
        FROM
            hejy_Tc230128 AS tc
        JOIN
            hejy_Teachers230128 AS teachers ON tc.hjy_Tno230128 = teachers.hjy_Tno230128
        JOIN
            hejy_classes230128 AS Classes ON tc.hjy_clno230128 = Classes.hjy_clno230128
        JOIN
            hejy_Courses230128 AS Courses ON Classes.hjy_clno230128 = Courses.hjy_clno230128
        WHERE
            teachers.hjy_Tname230128 = Tname
    LOOP
        hjy_Tno230128 := tc.hjy_Tno230128;
        hjy_Tname230128 := tc.hjy_Tname230128;
        hjy_Cno230128 := tc.hjy_Cno230128;
        hjy_clname230128 := tc.hjy_clname230128;
        hjy_TCyear230128 := tc.hjy_TCyear230128;
        hjy_Cname230128 := tc.hjy_Cname230128;

        RETURN NEXT;
    END LOOP;

    RETURN;
END;
$$;

alter function hejy_select_teachers_courses230128(varchar) owner to opengaussuser;

