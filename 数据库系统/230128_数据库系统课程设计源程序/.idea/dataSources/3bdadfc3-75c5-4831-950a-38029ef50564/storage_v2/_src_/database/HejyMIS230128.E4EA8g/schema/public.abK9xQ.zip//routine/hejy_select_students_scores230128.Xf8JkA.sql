create function hejy_select_students_scores230128(sno character varying, year character varying)
    returns TABLE(hjy_cno230128 character varying, hjy_clname230128 character varying, hjy_scscore230128 integer, hjy_scyear230128 character varying, hjy_cname230128 character varying, hjy_ccredit230128 integer, hjy_cevaluation230128 character varying, hjy_cterm230128 character varying, hjy_cperiod230128 character varying)
    language plpgsql
as
$$
DECLARE
    sg RECORD;
BEGIN
    FOR sg IN
        SELECT
            sc.hjy_Cno230128,
            Classes.hjy_clname230128,
            sc.hjy_SCscore230128,
            sc.hjy_SCyear230128,
            Courses.hjy_Cname230128,
            Courses.hjy_Ccredit230128,
            Courses.hjy_Cevaluation230128,
            Courses.hjy_Cterm230128,
            Courses.hjy_Cperiod230128
        FROM
            hejy_Sc230128 AS sc
        JOIN
            hejy_Courses230128 AS Courses ON sc.hjy_Cno230128 = Courses.hjy_Cno230128
        JOIN
            hejy_classes230128 AS Classes ON sc.hjy_clno230128 = Classes.hjy_clno230128
        WHERE
            sc.hjy_Sno230128 = Sno AND sc.hjy_SCyear230128 = year
    LOOP
        hjy_Cno230128 := sg.hjy_Cno230128;
        hjy_clname230128 := sg.hjy_clname230128;
        hjy_SCscore230128 := sg.hjy_SCscore230128;
        hjy_SCyear230128 := sg.hjy_SCyear230128;
        hjy_Cname230128 := sg.hjy_Cname230128;
        hjy_Ccredit230128 := sg.hjy_Ccredit230128;
        hjy_Cevaluation230128 := sg.hjy_Cevaluation230128;
        hjy_Cterm230128 := sg.hjy_Cterm230128;
        hjy_Cperiod230128 := sg.hjy_Cperiod230128;
        
        RETURN NEXT;
    END LOOP;
    
    RETURN;
END;
$$;

alter function hejy_select_students_scores230128(varchar, varchar) owner to opengaussuser;

