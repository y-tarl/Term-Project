create function hejy_stulocation230128(pno character varying, cno character varying, dno character varying)
    returns TABLE(hjy_sno230128 character varying, hjy_sname230128 character varying, hjy_pname230128 character varying, hjy_ciname230128 character varying, hjy_dname230128 character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        students.hjy_Sno230128,
        students.hjy_Sname230128,
        provinces.hjy_Pname230128,
        cities.hjy_ciname230128,
        Districts.hjy_Dname230128
    FROM
        hejy_Students230128 AS students
    JOIN
        hejy_classes230128 AS Classes ON students.hjy_clno230128 = Classes.hjy_clno230128
    JOIN
        hejy_District230128 AS Districts ON students.hjy_Slocation230128 = Districts.hjy_Dno230128
    JOIN
        hejy_city230128 AS cities ON Districts.hjy_cino230128 = cities.hjy_cino230128
    JOIN
        hejy_Province230128 AS provinces ON cities.hjy_pno230128 = provinces.hjy_pno230128
    WHERE
        provinces.hjy_pno230128 = Pno
        AND cities.hjy_cino230128 = Cno
        AND Districts.hjy_Dno230128 = Dno;

    RETURN;
END;
$$;

alter function hejy_stulocation230128(varchar, varchar, varchar) owner to opengaussuser;

