create function check_student_sex() returns trigger
    language plpgsql
as
$$
DECLARE
    student_sex VARCHAR(255);
BEGIN
    student_sex := CAST(NEW.hjy_Ssex230128 AS VARCHAR(255));

    IF student_sex != '男' AND student_sex !='女'  THEN
        RAISE EXCEPTION '性别输入不正确: %', NEW.hjy_Ssex230128;
    END IF;
    
    RETURN OLD;
END;
$$;

alter function check_student_sex() owner to opengaussuser;

