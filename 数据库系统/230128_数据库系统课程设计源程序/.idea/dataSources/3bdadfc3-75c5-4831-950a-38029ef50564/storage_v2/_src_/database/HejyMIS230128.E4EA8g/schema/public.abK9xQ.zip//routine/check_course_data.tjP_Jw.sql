create function check_course_data() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.hjy_Ccredit230128 <= 0 OR NEW.hjy_Cperiod230128 <= 0 THEN
        RAISE EXCEPTION 'Invalid course data: hjy_Ccredit230128=%, hjy_Cperiod230128=%',
            NEW.hjy_Ccredit230128, NEW.hjy_Cperiod230128;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function check_course_data() owner to opengaussuser;

