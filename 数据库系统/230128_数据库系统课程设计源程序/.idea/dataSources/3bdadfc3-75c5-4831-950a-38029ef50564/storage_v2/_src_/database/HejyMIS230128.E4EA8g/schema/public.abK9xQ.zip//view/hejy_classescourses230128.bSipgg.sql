create view hejy_classescourses230128
            (hjy_cno230128, hjy_clname230128, hjy_cname230128, hjy_ccredit230128, hjy_cevaluation230128,
             hjy_scyear230128, hjy_cterm230128, hjy_cperiod230128)
as
SELECT DISTINCT c.hjy_cno230128,
                cl.hjy_clname230128,
                c.hjy_cname230128,
                c.hjy_ccredit230128,
                c.hjy_cevaluation230128,
                sc.hjy_scyear230128,
                c.hjy_cterm230128,
                c.hjy_cperiod230128
FROM hejy_courses230128 c
         JOIN hejy_classes230128 cl ON c.hjy_clno230128::text = cl.hjy_clno230128::text
         JOIN hejy_sc230128 sc
              ON c.hjy_cno230128::text = sc.hjy_cno230128::text AND cl.hjy_clno230128::text = sc.hjy_clno230128::text;

alter table hejy_classescourses230128
    owner to opengaussuser;

